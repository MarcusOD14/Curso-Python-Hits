from setuptools import setup

setup(
    name="paquetecalculo",
    version="1.0",
    description="Operaciones matematicas",
    author="morrala",
    author_email="orralatony12@gmail.com",
    packages=["calculos", "calculos.basico"], #rutas/paquetes
    
)

#py ./setup.py  sdist
#pip -- version
#python -- version
#los paquetes se instalan en el equipo pero lo ideal seria seprarlos en entornos virtuales para que no tengan conflictos