def suma(op1 , op2):
    oper = op1 + op2
    print(f"El resultado de la suma es: {oper}")
    

def resta (op1 , op2):
    oper = op1 - op2
    print(f"El resultado de la resta es: {oper}")    