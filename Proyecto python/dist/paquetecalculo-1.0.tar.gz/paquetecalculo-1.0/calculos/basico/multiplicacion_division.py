def multiplicación(op1 , op2):
    oper = op1 * op2
    print(f"El resultado de la multiplicación es: {oper}")
    

def división (op1 , op2):
    oper = op1 / op2
    print(f"El resultado de la división es: {oper}") 